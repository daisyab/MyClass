/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author guestu
 */
public class Helloworld extends GeneratedClass{
    public static void main(String[] args){
        System.out.println("Hello everyone!");
    }
    
}
